from fastapi import FastAPI
from pydantic import BaseModel
import joblib
import numpy as np

# Load the trained model
model = joblib.load('engine.pkl')
vectorizer=joblib.load("vectorizer.pkl")

# Create FastAPI app instance
app = FastAPI()

# Prediction endpoint
@app.post("/predict/")
def predict(input_data: str):
    input_features = vectorizer.transform([input_data.text])
    prediction = model.predict(input_features)
    return {"prediction": prediction[0]}
