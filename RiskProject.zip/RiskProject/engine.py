# Load the csv file to pandas
import pandas as pd
df=pd.read_csv("balanced_risk_unique_body_priority_800.csv")
df.head()
import pandas as pd

# Finding duplicates
duplicates = df[df.duplicated()]

# This will show all rows that are duplicates (excluding the first occurrence)
print(duplicates)
df=df.drop_duplicates()
df.info()
import pandas as pd
from sklearn.preprocessing import LabelEncoder

label_encoder = LabelEncoder()

df['priority'] = label_encoder.fit_transform(df['priority'])

# Split data into training & test sets
from sklearn.model_selection import train_test_split

X_train, X_test, y_train, y_test = train_test_split(df['body'], df['priority'], test_size=0.2, random_state=42, stratify=df["priority"])

from sklearn.feature_extraction.text import TfidfVectorizer

# Convert text to numerical features using TF-IDF
vectorizer = TfidfVectorizer()
X_train_tfidf = vectorizer.fit_transform(X_train)
X_test_tfidf = vectorizer.transform(X_test)
# Train Random Forest model
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import GridSearchCV

rf_model = RandomForestClassifier(n_estimators=100, class_weight='balanced', random_state=42)

# Define the parameter grid
param_grid = {
    'n_estimators': [50, 100, 200],
    'max_depth': [10, 20, 30],
    'min_samples_split': [2, 5, 10],
    'min_samples_leaf': [1, 2, 4],
    'max_features': ['sqrt', 'log2', None]
}

# Set up GridSearchCV
grid_search = GridSearchCV(estimator=rf_model, param_grid=param_grid, cv=5, n_jobs=-1, verbose=2)

# Fit the model
grid_search.fit(X_train_tfidf, y_train)

# Extracting the best model from grid search cv
best_rf_model = grid_search.best_estimator_

import joblib
joblib.dump(best_rf_model, "engine.pkl")
joblib.dump(vectorizer, "vectorizer.pkl")